# A simple program that will convert inches to millimeters

class Converter:

    def convert(self, inches):
        return inches * 25.4
