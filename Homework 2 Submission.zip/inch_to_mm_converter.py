# A simple program that will convert inches to millimeters

def main():
	print ("This program will convert millimeters into inches")

	inches = float(input("Please enter the number of inches: "))
	millimeters = inches * 25.4

	print (str(inches) + " inches is the equivalence of " + str(millimeters) + " millimeters")

main()
